# LOVE2D-Tutorials
*LINK PARA DOWLOAD DO LOVE2D:*
  https://love2d.org/
  
- Exemplos de alguns usos do LOVE2D.
  - Aprendendo a mover uma imagem na tela
  - Criando um mundo e colocando corpos nele
  - Aprendendo a utilizar música e efeitos
  - Utilizar sprites utilizando a lib ANIM8
  - Sincronizar sprites com Hitbox
  - STI(simple tiled implementation)
  - BUMP(fisica)
  - GAMERA(sistema de cameras)
  
